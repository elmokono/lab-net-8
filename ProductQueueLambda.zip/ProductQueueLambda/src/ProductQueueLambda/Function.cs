using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DataModel;
using Amazon.Lambda.Core;
using Amazon.Lambda.SQSEvents;
using System.Text.Json;

// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.SystemTextJson.DefaultLambdaJsonSerializer))]

namespace ProductQueueLambda;

public class Function
{
    private readonly DynamoDBContext _dynamoDBContext;

    public Function()
    {
        var dbConfig = new AmazonDynamoDBConfig
        {
            ServiceURL = "http://localhost:4566",
            RegionEndpoint = Amazon.RegionEndpoint.USEast1
        };

        var dbClient = new AmazonDynamoDBClient(dbConfig);
        _dynamoDBContext = new DynamoDBContext(dbClient);
    }
    /// <summary>
    /// A simple function that takes a string and does a ToUpper
    /// </summary>
    /// <param name="input">The event for the Lambda function handler to process.</param>
    /// <param name="context">The ILambdaContext that provides methods for logging and describing the Lambda environment.</param>
    /// <returns></returns>
    public async Task<string> FunctionHandler(SQSEvent sqsEvent, ILambdaContext context)
    {
        try
        {
            foreach (var record in sqsEvent.Records)
            {
                var product = JsonSerializer.Deserialize<ProductDto>(record.Body);
                //do some work, validations, etcs...
                await _dynamoDBContext.SaveAsync(product);

            }
        }
        catch (Exception ex)
        {
            return $"ERROR {ex.Message}";
        }

        return "OK";
    }
}

[DynamoDBTable("Products")]
internal class ProductDto
{
    [DynamoDBHashKey]
    public string ProductId { get; set; }
    [DynamoDBProperty]
    public string Description { get; set; }
    [DynamoDBProperty]
    public string Name { get; set; }
    [DynamoDBProperty]
    public int Stock { get; set; }
    [DynamoDBProperty]
    public decimal Price { get; set; }
}